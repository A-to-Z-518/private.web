<template>
  <div >
    asedfasdfaseffdsaf
  </div>
</template>

<script>
export default {
  name:'Home',
  data(){

  }
  
}
</script>

<style >

</style>

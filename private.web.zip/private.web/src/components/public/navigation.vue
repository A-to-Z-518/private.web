<template>
<div class = 'app'>
  <link href="https://how2j.cn/study/css/bootstrap/3.3.6/bootstrap.min.css" rel="stylesheet">
  <nav class="bac navbar-static-top">
    <input type = 'text' placeholder = 'webpack'>
    <button class="btn btn-sm btn-info input">搜索</button>
    <!-- <button class="btn btn-sm btn-danger">按钮3</button> -->
  </nav>
    <router-link to = '/vue' target = '_blank'><isart></isart></router-link>
    <div @click="onoutwchat" href = 'javascript:;' class = 'textwchat' title = '点击扫码加微信'><img class = 'wchat img-rounded'  src="../../assets/pic/微信.jpg" >微信</div>
    <img  :class = '{onwchat:isonwchat,outwchat:isoutwchat}' src="../../assets/pic/二维码.jpg">
    <div @click="onoutqq" href = 'javascript:;' class = 'textqq' title = '点击扫码加qq'><img class = 'qq img-rounded'  src="../../assets/pic/qq图标.jpg" >QQ</div>
    <img  :class = '{onqq:isonqq,outqq:isoutqq}' src="../../assets/pic/qq.jpg">
</div>
</template>

<script>
import isart from'./art.vue'
export default {
  el:'.app',
  data(){
    return{
      isonwchat:false,
      isoutwchat:true,
      isonqq:false,
      isoutqq:true,
    }
  },
  methods:{
    onoutwchat(){
      this.isonwchat = !this.isonwchat
      this.isoutwchat = !this.isoutwchat
    },
    onoutqq(){
      this.isonqq = !this.isonqq
      this.isoutqq = !this.isoutqq
    }
  },
  components:{
    isart:isart,
  }
}
</script>

<style>
  
  nav.bac{
    background:#555555;
    height:50px;
    width:1349px;
  }
  button:focus{     /*消除button点击时出现的边框*/
    outline: 0;
    }
  button.input{
    position:absolute;
    top:12px;
    left:1270px;
    width:60px;
  }
  select.personal{
    position:absolute;
    top:12px;
    left:1230px;
    width:100px;
  }
  option{
    background:rgb(241, 233, 218);
    color:black;
    font-size:15px;
  }
  input{
    position:absolute;
    width:200px;
    height:28px;
    top:13px;
    left:1060px;
    transition:0.5s;
  }
  input:hover{
    position:absolute;
    width:300px;
    height:28px;
    top:13px;
    left:960px;
  } 
  .wchat{
    width:20px;
    height:20px;
  }
  .textwchat{
    width:50px;
    height:40px;
    position:absolute;
    top:15px;
    left:180px;
    color:rgb(206, 206, 206);
    transition:0.3s;
  }
  .textwchat:hover{
    width:50px;
    height:40px;
    position:absolute;
    top:15px;
    left:180px;
    color:rgb(255, 255, 255);
    text-decoration:none;
  }
  .onwchat{
    width:200px;
    height:200px;
    transition:0.5s;
    position:absolute;
    top:50px;
    left:40px;
  }
  .outwchat{
    width:200px;
    height:0px;
    transition:0.5s;
    position:absolute;
    top:50px;
    left:40px;
  }
  .qq{
    width:20px;
    height:20px;
  }
  .textqq{
    width:50px;
    height:40px;
    position:absolute;
    top:15px;
    left:250px;
    color:rgb(206, 206, 206);
    transition:0.3s;
  }
  .textqq:hover{
    width:50px;
    height:75px;
    position:absolute;
    top:15px;
    left:250px;
    color:rgb(255, 255, 255);
    text-decoration:none;
  }
  .onqq{
    width:200px;
    height:300px;
    transition:0.5s;
    position:absolute;
    top:50px;
    left:240px;
  }
  .outqq{
    width:200px;
    height:0px;
    transition:0.5s;
    position:absolute;
    top:50px;
    left:240px;
  }
</style>
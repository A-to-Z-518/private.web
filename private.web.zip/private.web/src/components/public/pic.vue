<template>
  <div class = 'app'>
    <div class = 'pic'>
      <ul class = 'slide-auto'>
        <li class = 'one'><img src="../../assets/pic/轮播图1.png" class = 'img'></li>
        <li class = 'two'><img src="../../assets/pic/轮播图2.png" class = 'img'></li>
        <li class = 'three'><img src="../../assets/pic/轮播图3.png" class = 'img'></li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  el:'.app',
  data(){

  }
}
</script>

<style>
  img.img{
    width:300px;
    height:203px;
    margin:0;
    padding:0;
  }
  .pic{
    /* border:1px red solid; */
    position:absolute;
    left:-105px;
    width:300px;
    height:200px;
    text-align:center;
    color:#FFF;
    overflow:hidden;
    margin:10px 10px;
  }
  .pic ul{
    margin:0px;
    padding:0;
    width: 1200px;
}
  .pic li{
      float: left;
      width: 300px;
      height: 200px;
      list-style: none;
      line-height: 200px;
  }
  .one{
    background: #9fa8ef;
  }
  .two{
    background: #ef9fb1;
  }
  .three{
    background:rgb(143, 66, 66);
  }
  @keyframes marginLeft{
      0%{margin-left: 0;}
      28.5%{margin-left: 0;}
      33.3%{margin-left: -300px;}
      62%{margin-left: -300px;}
      66.7%{margin-left: -600px;}
      95.2%{margin-left: -600px;}
      100%{margin-left: 0;}
  }
  .pic .slide-auto{      /*  设置过度时长 */
    animation:marginLeft 8s infinite;
  } 
  
</style>
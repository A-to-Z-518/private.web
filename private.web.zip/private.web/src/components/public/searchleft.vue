<template>
  <div class = 'app'>
    <div class = 'body'>
      <!-- <button @click = 'vue'>VUE</button> -->
      <router-view></router-view>
    </div>
    <div class = 'searchleft'>
      <div >
        <p class = 'left'>分类</p>
        <hr class = 'hr'/> 
        <div class = 'left1' >
          <button @click = 'vue' title = 'VUE' class = 'click'>VUE</button><br/>
          <button @click = 'html' title = 'HTML' class = 'click'>HTML</button><br/>
          <button @click = 'css' title = 'CSS' class = 'click'>CSS</button><br/>
          <button @click = 'js' title = 'JavaScript' class = 'click'>JavaScript</button>
        </div>
        
        <p class = 'left'>实用工具</p>
        <hr class = 'hr'/> 
        <div class = 'left2'>
          <a href="https://colorhunt.co/" title = 'web前端各种配色' target = 'target'><span class = 'btn btn-xs'>web配色</span></a>
          <a href="https://tool.lu/json/" title = 'Json数据在线转换' target = 'target'><span class = 'btn btn-xs'>Json数据转换</span></a>
          <a href="https://818ps.com/" title = '免费的设计网站' target = 'target'><span class = 'btn btn-xs '>图怪兽</span></a>
          <a href="https://animate.style/" title = 'VUE在线样式' target = 'target'><span class = 'btn btn-xs'>VUE在线样式</span></a>
          <a href="https://bigjpg.com/" title = '无损图片放大器' target = 'target'><span class = 'btn btn-xs'>图片无损放大</span></a>
          <a href="https://www.shejidaren.com/" title = '提供灵感的设计网站' target = 'target'><span class = 'btn btn-xs'>设计达人</span></a>
        </div>

        <p class = 'left'>部分代码</p>
        <hr class = 'hr'/> 
        <ispic></ispic>
      </div>
    </div>
  </div>
</template>

<script>
import ispic from'./pic.vue'
export default {
  el:'.app',
  data(){
    return{

    }
  },
  components:{
    ispic:ispic,
  },
  methods:{
    vue(){
      this.$router.push('Vue')
    },
    css(){
      this.$router.push('Css')
    },
    html(){
      this.$router.push('Html')
    },
    js(){
      this.$router.push('Js')
    }
  }
}
</script>

<style>
  
  .hr{
    width:130px;
    border:none;
    border-top:2px solid rgb(7, 7, 7);
    margin:0  auto;
  }
  .left{
    margin-bottom:0px;
    float:right;
    margin-right:40px;
    margin-top:15px;
    font-family: '楷体';
    font-size:20px;
    font-weight:bold;
  }
  .left1{ 
    margin-bottom:0px; 
    margin-left:50px; 
    margin-top:15px; 
    font-family: '楷体'; 
    font-size:15px; 
  }
  .left2{
    margin-bottom:0px;
    margin-left:5px;
    margin-top:5px;
    font-family: '楷体';

    /* text-align:center; */
  }
  .left2 span{
    background:rgb(193, 193, 193);
    margin-left:3px;
    margin-top:4px;
    font-size:15px;
    transition:0.3s;
    z-index:0;
  }
  .left2 span:hover{
    background:rgb(235, 232, 232);
    margin-left:2px;
    margin-top:5px;
    font-size:15px;
    transform:scale(1.3);
    z-index:1;
    
  }
  .left2 a{
    color:black;
  }
  .searchleft{
    /* background:red; */
    /* border:1px blue solid; */
    width:200px;
    height:400px;
    position:absolute;
    top:60px;
    left:965px;
  }
  div.body{
    /* border:1px solid red; */
    position:absolute;
    top:50px;
    left:0px;
    width:900px;
    height:auto;
  }
  .click{
    font-family:'楷体';
    border:none;
    padding-bottom:10px;
    transition:0.3s;
  }
  button:focus{     /*消除button点击时出现的边框*/
    outline: 0;
    }
  .click:hover{
    border:none;
    padding-bottom:10px;
    color:rgb(0, 4, 255);
    transition:0.3s;
    transform:scale(1.3);
  }
</style>
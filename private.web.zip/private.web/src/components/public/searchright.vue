<template>
  <div class = 'app'>
    <link href="https://how2j.cn/study/css/bootstrap/3.3.6/bootstrap.min.css" rel="stylesheet">
    <div class = 'searchright '>
      <div  class = 'title img-rounded'>
        常用站点
      </div>
      <div class = 'usedpic'>
        <a :href = 'cnkihref' target = 'target' title = '中国知网'>
          <img src="../../assets/pic/中国知网.png" class = 'leftpic img-rounded'></a>
        <a :href = 'csdnhref' target = 'target' title = 'CSDN'>
          <img src="../../assets/pic/csdn.png" class = 'rightpic img-rounded'></a>
        <a :href = 'csdnhref' target = 'target' title = '电影解码'>
          <img src="../../assets/pic/电影解码.png" class = 'leftpic img-rounded'></a>
      </div>
    </div>
    
  </div>
</template>

<script>
export default {
  el:'.app',
  data(){
    return{
      cnkihref:'https://www.cnki.net/',
      csdnhref:'https://www.csdn.net/'
    }
  }
}
</script>

<style>
 .searchright{
   /* border:1px red solid; */
   position:fixed;
   top:60px;
   left:1150px;
   width:195px;
   height:400px;
 }
 div.title{
   width:150px;
   height:60px;
   background:rgb(196, 193, 193);
   margin:0 auto;
   margin-top:20px;
   font-family:'楷体';
   font-size:18px;
   font-weight:bold;
   text-align:center;
   line-height: 55px;
 }
 .usedpic{
   margin-left:40px;
 }
 img{
  transform:rotate(0deg) scale(1);
  transition:1.5s;
  z-index:0;
}
.leftpic{
  width:100px;
  height:100px;
  margin-top:20px;
}
.leftpic:hover{
  transform:rotate(-360deg);
  transition:1.5s;
  z-index:1;
}
.rightpic{
  width:100px;
  height:100px;
  margin-top:20px;
}
.rightpic:hover{
  transform:rotate(360deg);
  transition:1.5s;
  z-index:1;
}
</style>
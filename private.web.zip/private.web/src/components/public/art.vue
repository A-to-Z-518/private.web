<template>
  <div>
    <div class = 'size'>
      <div class = 'abab' @click = 'school'>私房站</div>
      <div class = 'ababs'>私房站</div>
    </div>
  </div>
</template>

<script>
export default {
	name:'.app',
	data(){
		return{
			
		}
	},
	methods:{
		school(){

		}
	}
}
</script>

<style>
  *{
    margin:0;
    padding:0;
  }
  div.size{
    width:100px;
    height:30px;
    position: absolute;
    top:0px;
    left:50px;
    /* border:1px blue solid; */
  }
  .abab{
		text-decoration:none;
		z-index:0;
		font-size: 30px;
		font-weight: 1;
		font-family: '宋体';
		color:rgb(235, 255, 237);
		transform: rotate(0deg) skew(10deg);
		text-shadow: 
			-1px 1px 0 rgb(146, 134, 255),
			-2px 2px 0 rgb(184, 174, 174), 
			-3px 3px 0 rgb(4, 250, 16),
			-4px 4px 0 rgb(184, 174, 174),
			-5px 5px 0 rgb(255, 0, 0);
			
		
}

.ababs {
	position:absolute;
	top:14px;
	left:-14px;
	transform: rotate(0deg) skew(10deg);
	z-index: 0;
	font-size: 30px;
	font-weight: 900;
	font-family: '宋体';
	color: #cacaca;
	filter:blur(6px)
}

</style>
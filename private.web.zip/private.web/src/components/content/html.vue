<template>
  <div>
    <div class = 'all'>
      <router-link to="/vueb" target="_blank" class = 'font' title = '404'><h2 ><b>404</b></h2></router-link>
      <nav><img src = '../../assets/pic/404.png' ></nav>
      <p >404404404404404404404404404404404404404404404404404404404404404404404”</p>
      <router-link to="/vuea" target="_blank" style = "font-family:'楷体;font-size:15px" title = 'VUE初识'><b>阅读原文>></b></router-link>
    </div>
    
    <div class = 'all'>
      <router-link to="/vueb" target="_blank" class = 'font' title = '404'><h2 ><b>404</b></h2></router-link>
      <nav><img src = '../../assets/pic/404.png' ></nav>
      <p >404404404404404404404404404404404404404404404404404404404404404404404”</p>
      <router-link to="/vuea" target="_blank" style = "font-family:'楷体;font-size:15px" title = 'VUE初识'><b>阅读原文>></b></router-link>
    </div>
  </div>
</template>

<script>
export default {
  name:'html',
  created(){
    document.title = ('HTML')
  }
}
</script>

<style>

</style>
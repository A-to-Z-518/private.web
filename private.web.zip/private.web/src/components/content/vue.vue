<template>
  <div >
    <div class = 'all'>
      <router-link to="/vuea" target="_blank" class = 'font' title = 'VUE初识'><h2 ><b>VUE初识</b></h2></router-link>
      <nav><img src = '../../assets/pic/frame.jpg' ></nav>
      <p >如果你是一个前端开发人员，当你在开发新项目时，想必一定被人问过“你用的是什么框架？”进而开展各种前端技术话题。但是对于初入门的前端小白来说，遇到这样的问题估计会产生一系列的疑问“前端框架是什么意思？前端框架有什么用？前端框架有哪些... ”</p>
      <router-link to="/vuea" target="_blank" style = "font-family:'楷体;font-size:15px" title = 'VUE初识'><b>阅读原文>></b></router-link>
    </div>

    <div class = 'all'>
      <router-link to="/vueb" target="_blank" class = 'font' title = '404'><h2 ><b>404</b></h2></router-link>
      <nav><img src = '../../assets/pic/404.png' ></nav>
      <p >404404404404404404404404404404404404404404404404404404404404404404404”</p>
      <router-link to="/vuea" target="_blank" style = "font-family:'楷体;font-size:15px" title = 'VUE初识'><b>阅读原文>></b></router-link>
    </div>
    
  </div>
</template>

<script>
export default {
  name:'vue',
  methods:{
    // vuea(){
    //   this.$router.push('/Vue/vuea')
    // }
  },
  created(){
    document.title = ('VUE')
  }

}
</script>

<style>
  .font{
    color:black;
    font-family:'楷体';
    /* font-weight:bold; */
    text-decoration:none;
    transition:0.5s;
    
  }
  .all{
    width:800px;
    height:auto;
    background:rgb(196, 193, 193);
    margin:30px auto;
    padding-left:10px;
    padding-bottom:20px;
    transition:0.5s;
    border:10px solid #E8E8E8;
  }
  .all:hover{
    width:800px;
    height:auto;
    background:#E8E8E8;
    margin:30px auto;
  }
  .all nav{
    text-align:center;
  }
  .all{
    transition:0.5s;
  }
  .all a:hover{
    text-decoration:none;
    color:rgb(139, 139, 139);
  }
  .all nav img{
    width:450px;
    height:250px;
    margin:15px auto;
  }
  p{
    text-indent:40px;
  }
</style>
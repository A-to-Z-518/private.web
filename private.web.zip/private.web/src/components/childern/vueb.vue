<template>
  <div class = 'all text'>
    <h2>404</h2>
    <div style = "text-align:center"><img src="../../assets/pic/404.png" alt=""></div>
  </div>
</template>

<script>
export default {
  name:'vueb',
  created(){
    document.title = ('404')
  }
}
</script>

<style>

</style>
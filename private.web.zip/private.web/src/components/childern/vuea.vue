<template>
  <div class = 'all text'>
    <h2 align = 'center'>VUE初识</h2>
    <div >
      <p>如果你是一个前端开发人员，当你在开发新项目时，想必一定被人问过“你用的是什么框架？”进而开展各种前端技术话
         题。但是对于初入门的前端小白来说，遇到这样的问题估计会产生一系列的疑问“前端框架是什么意思？前端框架有什么用？前端框架有哪些... ”</p>
      <h3>一、认识Vue.js</h3>
      <p>1.什么是Vue</p>
      <p>Vue是一个渐进式的框架，什么是渐进式？渐进式意味着你可以将Vue作为你应用的一部分嵌入其中，带来更丰富的交互体验。或者如果你希望将
        更多的业务逻辑使用Vue实现，那么Vue的核心库以及其生态系统。比如Core+Vue-router+Vuex，也可以满足你各种各样的需求。</p>
      <p>2.Vue有很多特点和Web开发中常见的高级功能</p>
      <p>解耦视图和数据、可复用的组件、前端路由技术、状态管理、虚拟DOM，学习Vue并不需要你具备其他类似于Angular、React，甚至是jQuery的经验。但是需要具备一定的HTML、CSS、JavaScript基础。</p>
      <h3>二、Vue安装及简单使用</h3>
      <p>1.安装</p>
      <p>引入Vue的方式有很多，可以直接CDN引入，建议去<a href = 'https://cn.vuejs.org/v2/guide/' target = 'target' title = 'vue官网'>Vue官网</a>下载HBuilderX，这里面创建项目会自动引入Vue框架</p>
      <div style = 'text-align:center'><img src="../../assets/pic/cdn引入.png" style = 'padding:0 auto;'></div>
      <p>2.如何使用</p>

    </div>
  </div>
</template>

<script>
export default {
  name:'vuea',
  created(){
    document.title = ('Vue初识')
  } 
}
</script>

<style>
  .text{
    font-family:'楷体';
    font-size:20px;
  }
  
</style>
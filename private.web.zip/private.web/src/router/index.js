import { createRouter, createWebHistory } from 'vue-router'
// import App from '../../src/App.vue'
import Home from '../views/Home.vue'

import Vue from '../components/content/vue.vue'
  import Vuea from '../components/childern/vuea.vue'
  import Vueb from '../components/childern/vueb.vue'
import Html from '../components/content/html.vue'
import Css from '../components/content/css.vue'
import Js from '../components/content/js.vue'

const routes = [
  {
    path:'/',
    redirect: 'Vue'
  },
  // {
  //   path:'/App',
  //   component:App
  // },
  {
    path: '/Home',
    component: Home
  },
  {
    path:'/Vue',
    component:Vue,
  },
    {
    path:'/vuea',
    component:Vuea
    },
    {
      path:'/vueb',
      component:Vueb
      },
  {
    path:'/Js',
    component:Js
  },
  {
    path:'/Css',
    component:Css
  },
  {
    path:'/HTML',
    component:Html
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router

<template>
  <div >
    <!-- <ispic></ispic> -->
    <!-- <isart></isart> -->
    <issearchleft></issearchleft>
    <issearchright></issearchright>
    <isnavigation></isnavigation>
    
  </div>
</template>
<script>
  // import ispic from'./components/public/pic.vue'
  // import isart from'./components/public/art.vue'
  import isnavigation from'./components/public/navigation.vue'
  import issearchleft from'./components/public/searchleft.vue'
  import issearchright from'./components/public/searchright.vue'
  export default{
    name:'.app',
    data(){
      return {
        
      }
    },
    methods:{
      
    },
    components:{
      // ispic:ispic,
      // isart:isart,
      isnavigation:isnavigation,
      issearchleft:issearchleft,
      issearchright:issearchright,
    },
    created(){
      document.title = ('首页')
    }
  }
</script>
<style>
  @import "./assets/css/app.css";
  body{
    background-image:url('./assets/pic/background.jpg')
  }
  /* div.frist{
    position:absolute;
    top:260px;
    left:50px;
    background:#E8E8E8;
    width:900px;
    height:auto;
  } */
</style>
